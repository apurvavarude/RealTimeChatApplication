

<?php

include('php/config.php'); 

session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); 
    exit;
}


$user_id = $_SESSION['user_id'];

if (isset($_POST['update'])) {
  
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    

    $sql = "UPDATE users SET name='$fname', email='$email' WHERE id='$user_id'";

    if (mysqli_query($conn, $sql)) {
        echo "Profile updated successfully!";
    } else {
        echo "Error updating profile: " . mysqli_error($conn);
    }
}
?>
